﻿Public Class NFTAAlert

    Public Shared Function GetAlertsByParentCategory(ByVal categoryId As Integer) As List(Of AlertView)
        Dim alertdb As nftaDataContext = New nftaDataContext
        Dim myResult As List(Of AlertView) = (From r In alertdb.AlertViews.Cast(Of AlertView)() Where r.Parent_Id = categoryId And r.EndDate.Value >= DateTime.Now.Date Order By r.CategoryName).ToList
        Return If(Not IsNothing(myResult) And myResult.Count > 0, myResult, Nothing)
    End Function

End Class
