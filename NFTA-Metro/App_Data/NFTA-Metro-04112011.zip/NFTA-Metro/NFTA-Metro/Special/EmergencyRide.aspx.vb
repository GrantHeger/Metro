﻿Imports System.Net.Mail

Partial Public Class _EmergencyRide
    Inherits System.Web.UI.Page


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Private Sub btnSubmit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnER.Click



        'classic asp code to convert to .net
        '<%

        'Dim STRname, STRaddress, STRcity, STRzip, STRhomephone, STRworkphone, STRemployer, STRemployeraddress, STRflashnumber, STRwhenpurchased, STRwherepurchased, STRroutesused, body

        'STRname = Request.Form("name")
        'STRaddress = Request.Form("address")
        'STRcity = Request.Form("city")
        'STRzip = Request.Form("zip")
        'STRhomephone = Request.Form("homephone")
        'STRworkphone = Request.Form("workphone")
        'STRemployer = Request.Form("employer")
        'STRemployeraddress = Request.Form("employeraddress")
        'STRflashnumber = Request.Form("flashnumber")
        'STRwhenpurchased = Request.Form("whenpurchased")
        'STRwherepurchased = Request.Form("wherepurchased")
        'STRroutesused = Request.Form("routesused")


        'body = "<b>Name:</b> " & STRname & "<br>"
        'body = body + "<b>Street Address:</b> " & STRaddress & "<br>"
        'body = body + "<b>City/Town:</b> " & STRcity & "<br>"
        'body = body + "<b>Zip:</b> " & STRzip & "<br>"
        'body = body + "<b>Home Phone:</b> " & STRhomephone & "<br>"
        'body = body + "<b>Work Phone:</b> " & STRworkphone & "<br>"
        'body = body + "<b>Place of Employment:</b> " & STRemployer & "<br>"
        'body = body + "<b>Address:</b> " & STRemployeraddress & "<br>"
        'body = body + "<b>Current Pass #:</b> " & STRflashnumber & "<br>"
        'body = body + "<b>Date Purchased:</b> " & STRwhenpurchased & "<br>"
        'body = body + "<b>Where Purchased:</b> " & STRwherepurchased & "<br>"
        'body = body + "<b>Regular Bus Service/Routes Used:</b> " & STRroutesused & "<br>"

        'sendUrl = "http://schemas.microsoft.com/cdo/configuration/sendusing"
        'smtpUrl = "http://schemas.microsoft.com/cdo/configuration/smtpserver"


        '' Set the mail server configuration
        'objConfig = CreateObject("CDO.Configuration")
        'objConfig.Fields.Item(sendUrl) = 2 ' cdoSendUsingPort
        ''objConfig.Fields.Item(smtpUrl)="relay-hosting.secureserver.net"
        'objConfig.Fields.Item(smtpUrl) = "s2smtpout.secureserver.net"
        'objConfig.Fields.Update()


        ''send email		 			
        'MyMail = CreateObject("CDO.Message")
        'MyMail.Configuration = objConfig
        ''MyMail.From strEmail
        'MyMail.From = "admin@niagarafrontiertransportationauthority.com"
        'MyMail.To = "info@nfta.com"
        'MyMail.Bcc = "corey_hacker@nfta.com"
        'MyMail.ReplyTo = "info@nfta.com"
        'MyMail.Subject = "Emergency Ride Registration | " & STRname
        'MyMail.HTMLBody = body
        'MyMail.Send()

        'Response.Write("<br><br><BR><BR><BR><h3 align=""center"">Thank you " & STRname & " for registering for the Emergency Ride Program.</h3>")

        'MyMail = Nothing

        '%>    


    End Sub

End Class