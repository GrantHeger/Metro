﻿Partial Public Class _Alerts
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        GetData()
    End Sub

    Protected Sub GetData()
        Dim cats() = {2, 5}
        For Each cat In cats
            Dim results = NFTAAlert.GetAlertsByParentCategory(cat)
            Dim tbl As DataTable = New DataTable
            If Not IsNothing(results) Then
                Dim rw As DataRow
                With tbl
                    .Columns.Add("CategoryName", GetType(String))
                    .Columns.Add("MessageEmail", GetType(String))
                End With
                For Each result In results
                    rw = tbl.NewRow
                    rw.Item("CategoryName") = result.CategoryName
                    rw.Item("MessageEmail") = result.MessageEmail
                    tbl.Rows.Add(rw)
                Next
            End If
            rptAlerts.DataSource = tbl
            rptAlerts.DataBind()
        Next
    End Sub

End Class