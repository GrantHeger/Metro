﻿Imports System.IO

Public Class AddPageClass

    Public Shared Function AddClass(ByVal pg As String) As String
        Select Case Split(pg.ToString, "\")(UBound(Split(pg.ToString, "\"))).ToString.ToLower
            Case "alerts"
                Return "pageAlerts"
            Case "routes"
                Return "pageRoutes"
            Case "parkride"
                Return "pageParkRide"
            Case "tips"
                Return "pageTips"
            Case "special"
                Return "pageSpecialNeeds"
            Case "trip"
                Return "pageTrip"
            Case Else
                Return "pageHome"
        End Select
    End Function

End Class
