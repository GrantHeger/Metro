﻿Partial Public Class _TripNFTA
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    'http://metrotrip.nfta.com/cgi-bin/itin.pl?action=entry&resptype=U&Orig=181 Ellicott&Orig1=Buffalo Airport&Dest=235 Main Street&Dest1=Buffalo Zoo&Date=03/31/11&Arr=A&Time=02:39 PM&Walk=0.50&Min=T
    'http://metrotrip.nfta.com/cgi-bin/itin.pl


    Protected Function buildTripPlanLink() As String
        Dim linkAmp As String = "&"
        Dim strAction As String = "action=entry"
        Dim strResptype As String = "resptype=U"
        Dim strOrig As String = "Orig=" & Orig.Text
        Dim ddlOrig1 As String = "Orig1=" & "181 Ellicott"
        Dim strDest As String = "Dest=" & Dest.Text
        Dim ddlDest1 As String = "Dest1="
        Dim strDate As String = "Date=" & TripDate.Text
        Dim radArr As String = "Arr=" & Arr.SelectedValue
        Dim strTime As String = "Time=" & TripTime.Text
        Dim strWalk As String = "Walk=" & "0.05"
        Dim strMin As String = "Min=" & "T"


        'Dim val As String = "value=" & ddlProduct.SelectedValue  'Set the value
        'Dim newprod As String = "item_name=" & ddlProduct.SelectedItem.Text  'Sets the item name of the new product
        'Dim client As String = "client=" & Membership.GetUser.ToString
        Dim TripLink As String = "http://metrotrip.nfta.com/cgi-bin/itin.pl?" & _
            strAction & linkAmp & strResptype & linkAmp & strOrig & linkAmp & ddlOrig1 & _
             linkAmp & strDest & linkAmp & ddlDest1 & linkAmp & strDate & _
             linkAmp & radArr & linkAmp & strTime & linkAmp & strWalk & linkAmp & strMin
        'Globals._client & Globals._urlVarSeperator & _
        'Globals._reatt & Globals._urlVarSeperator & _
        'newprod & Globals._urlVarSeperator & _
        'Val() & Globals._urlVarSeperator '& Globals._urlVarSeperator
        Return TripLink
    End Function


    Protected Sub btnTrip_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnTrip.Click
        Response.Redirect(buildTripPlanLink())
    End Sub

End Class