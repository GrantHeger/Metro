﻿Partial Public Class _TripGoogle
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        'litDateNow.Text = Date.Today

    End Sub

End Class